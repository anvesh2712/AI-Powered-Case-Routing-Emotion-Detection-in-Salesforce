# Named Credential Setup

- **Label**: HuggingFace_API  
- **Name**: HuggingFace_API  
- **URL**: https://api-inference.huggingface.co  
- **Identity Type**: Anonymous  
- **Authentication Protocol**: No Authentication  
- Check: Allow Callouts